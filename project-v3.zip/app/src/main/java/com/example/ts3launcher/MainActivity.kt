package com.example.ts3launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Awan dekoratif (digambar lewat kode, desain asli). */
class CloudView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F4EBD6") }
    private val spots = listOf(
        floatArrayOf(0.12f, 0.08f, 0.22f), floatArrayOf(0.85f, 0.20f, 0.18f),
        floatArrayOf(0.10f, 0.45f, 0.14f), floatArrayOf(0.90f, 0.60f, 0.20f),
        floatArrayOf(0.20f, 0.85f, 0.18f), floatArrayOf(0.75f, 0.93f, 0.15f)
    )
    override fun onDraw(c: Canvas) {
        for (s in spots) {
            val cx = s[0] * width
            val cy = s[1] * height
            val r = s[2] * width * 0.5f
            c.drawCircle(cx, cy, r * 0.6f, p)
            c.drawCircle(cx - r * 0.6f, cy + r * 0.15f, r * 0.45f, p)
            c.drawCircle(cx + r * 0.6f, cy + r * 0.15f, r * 0.45f, p)
            c.drawRoundRect(cx - r, cy + r * 0.2f, cx + r, cy + r * 0.6f, r * 0.2f, r * 0.2f, p)
        }
    }
}

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("ts3", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var coverImage: ImageView
    private lateinit var coverHint: TextView
    private lateinit var bgImage: ImageView

    private val ppssppPackages = listOf("org.ppsspp.ppsspp", "org.ppsspp.ppssppgold")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun panel(label: String, onClick: () -> Unit): FrameLayout {
        val tv = TextView(this).apply {
            text = label
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#FFD84D"))
            typeface = Typeface.create("serif", Typeface.BOLD_ITALIC)
            setShadowLayer(10f, 0f, 0f, Color.parseColor("#1E5AA8"))
        }
        return FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EAD9B5"))
                cornerRadius = dp(8).toFloat()
            }
            addView(tv, FrameLayout.LayoutParams(-1, -1))
            setOnClickListener { onClick() }
        }
    }

    private fun link(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#5C95A3")
        window.navigationBarColor = Color.parseColor("#5C95A3")

        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#6FA6B3")) }
        root.addView(CloudView(this), FrameLayout.LayoutParams(-1, -1))

        // Latar pilihan sendiri (opsional)
        bgImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE }
        root.addView(bgImage, FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32), dp(40), dp(32), dp(24))
        }

        // Cover pilihan sendiri
        val coverBox = FrameLayout(this).apply { setOnClickListener { pick(2, "image/*") } }
        coverImage = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        coverHint = TextView(this).apply {
            text = "Tap untuk pilih cover"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        coverBox.addView(coverImage, FrameLayout.LayoutParams(-1, -1))
        coverBox.addView(coverHint, FrameLayout.LayoutParams(-1, -1))
        content.addView(coverBox, LinearLayout.LayoutParams(-1, 0, 1f).apply { bottomMargin = dp(16) })

        content.addView(panel("Play") { launchGame() },
            LinearLayout.LayoutParams(-1, dp(84)).apply { bottomMargin = dp(16) })
        content.addView(panel("Select file iso") { pick(1, "*/*") },
            LinearLayout.LayoutParams(-1, dp(84)))

        status = TextView(this).apply {
            setTextColor(Color.parseColor("#1F3A44"))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        content.addView(status)

        val links = LinearLayout(this).apply { gravity = Gravity.CENTER }
        links.addView(link("Ganti cover") { pick(2, "image/*") })
        links.addView(link("Ganti latar") { pick(3, "image/*") })
        links.addView(link("Reset latar") {
            prefs.edit().remove("bg_uri").apply()
            bgImage.visibility = View.GONE
        })
        content.addView(links)

        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        loadImages()
        refreshStatus()
    }

    private fun refreshStatus() {
        val saved = prefs.getString("iso_uri", null)
        status.text = if (saved == null) "ISO belum dipilih" else "ISO: " + Uri.parse(saved).lastPathSegment
    }

    private fun loadImages() {
        prefs.getString("cover_uri", null)?.let {
            try { coverImage.setImageURI(Uri.parse(it)); coverHint.visibility = View.GONE } catch (e: Exception) {}
        }
        prefs.getString("bg_uri", null)?.let {
            try { bgImage.setImageURI(Uri.parse(it)); bgImage.visibility = View.VISIBLE } catch (e: Exception) {}
        }
    }

    private fun pick(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, code)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val key = when (requestCode) { 1 -> "iso_uri"; 2 -> "cover_uri"; else -> "bg_uri" }
        prefs.edit().putString(key, uri.toString()).apply()
        refreshStatus()
        loadImages()
    }

    private fun launchGame() {
        val saved = prefs.getString("iso_uri", null)
        if (saved == null) {
            Toast.makeText(this, "Pilih ISO dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val pkg = ppssppPackages.firstOrNull { isInstalled(it) }
        if (pkg == null) {
            Toast.makeText(this, "PPSSPP belum terinstall", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            component = ComponentName(pkg, "org.ppsspp.ppsspp.PpssppActivity")
            data = Uri.parse(saved)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka PPSSPP: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun isInstalled(pkg: String) = try {
        packageManager.getPackageInfo(pkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) { false }
}
