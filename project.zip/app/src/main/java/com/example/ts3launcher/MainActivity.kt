package com.example.ts3launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("ts3", MODE_PRIVATE) }
    private lateinit var status: TextView

    // Package name PPSSPP gratis dan Gold
    private val ppssppPackages = listOf("org.ppsspp.ppsspp", "org.ppsspp.ppssppgold")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        status = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER }
        val pick = Button(this).apply { text = "Pilih file ISO"; setOnClickListener { pickIso() } }
        val play = Button(this).apply { text = "Main Toy Story 3"; setOnClickListener { launchGame() } }

        root.addView(status)
        root.addView(pick)
        root.addView(play)
        setContentView(root)
        refreshStatus()
    }

    private fun refreshStatus() {
        val saved = prefs.getString("iso_uri", null)
        status.text = if (saved == null) "ISO belum dipilih" else "ISO: " + Uri.parse(saved).lastPathSegment
    }

    private fun pickIso() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 1 && resultCode == RESULT_OK && uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("iso_uri", uri.toString()).apply()
            refreshStatus()
        }
    }

    private fun launchGame() {
        val saved = prefs.getString("iso_uri", null)
        if (saved == null) {
            Toast.makeText(this, "Pilih ISO dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val pkg = ppssppPackages.firstOrNull { isInstalled(it) }
        if (pkg == null) {
            Toast.makeText(this, "PPSSPP belum terinstall", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            component = ComponentName(pkg, "org.ppsspp.ppsspp.PpssppActivity")
            data = Uri.parse(saved)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka PPSSPP: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun isInstalled(pkg: String) = try {
        packageManager.getPackageInfo(pkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) { false }
}
