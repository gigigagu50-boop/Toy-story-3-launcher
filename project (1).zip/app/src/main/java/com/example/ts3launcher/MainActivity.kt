package com.example.ts3launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("ts3", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var coverImage: ImageView
    private lateinit var coverHint: TextView

    private val ppssppPackages = listOf("org.ppsspp.ppsspp", "org.ppsspp.ppssppgold")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(2), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0F1B3D")
        window.navigationBarColor = Color.parseColor("#2A1B5E")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(24), dp(32), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0F1B3D"), Color.parseColor("#2A1B5E"))
            )
        }

        // Cover (gambar pilihan sendiri)
        val cover = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#3A2D7C"), Color.parseColor("#FF7A1A"))
            ).apply { cornerRadius = dp(24).toFloat() }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(24).toFloat())
                }
            }
            clipToOutline = true
            elevation = dp(12).toFloat()
            setOnClickListener { pick(2, "image/*") }
        }
        coverImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        coverHint = TextView(this).apply {
            text = "★\nTap untuk pilih cover"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        cover.addView(coverImage, FrameLayout.LayoutParams(-1, -1))
        cover.addView(coverHint, FrameLayout.LayoutParams(-1, -1))
        root.addView(cover, LinearLayout.LayoutParams(dp(220), dp(300)).apply { bottomMargin = dp(24) })

        val title = TextView(this).apply {
            text = "Toy Story 3"
            setTextColor(Color.WHITE)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#B8C0E0"))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(24))
        }
        root.addView(title)
        root.addView(status)

        val play = Button(this).apply {
            text = "▶  MAIN"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            background = roundBg(Color.parseColor("#FF7A1A"), 28)
            setOnClickListener { launchGame() }
        }
        val pick = Button(this).apply {
            text = "Pilih file ISO"
            setTextColor(Color.WHITE)
            background = roundBg(Color.TRANSPARENT, 28, Color.parseColor("#B8C0E0"))
            setOnClickListener { pick(1, "*/*") }
        }
        root.addView(play, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) })
        root.addView(pick, LinearLayout.LayoutParams(-1, dp(52)))

        setContentView(root)
        loadCover()
        refreshStatus()
    }

    private fun refreshStatus() {
        val saved = prefs.getString("iso_uri", null)
        status.text = if (saved == null) "ISO belum dipilih" else "ISO: " + Uri.parse(saved).lastPathSegment
    }

    private fun loadCover() {
        val saved = prefs.getString("cover_uri", null) ?: return
        try {
            coverImage.setImageURI(Uri.parse(saved))
            coverHint.visibility = View.GONE
        } catch (e: Exception) { /* abaikan */ }
    }

    private fun pick(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, code)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (requestCode == 1) {
            prefs.edit().putString("iso_uri", uri.toString()).apply()
            refreshStatus()
        } else if (requestCode == 2) {
            prefs.edit().putString("cover_uri", uri.toString()).apply()
            loadCover()
        }
    }

    private fun launchGame() {
        val saved = prefs.getString("iso_uri", null)
        if (saved == null) {
            Toast.makeText(this, "Pilih ISO dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val pkg = ppssppPackages.firstOrNull { isInstalled(it) }
        if (pkg == null) {
            Toast.makeText(this, "PPSSPP belum terinstall", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            component = ComponentName(pkg, "org.ppsspp.ppsspp.PpssppActivity")
            data = Uri.parse(saved)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal buka PPSSPP: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun isInstalled(pkg: String) = try {
        packageManager.getPackageInfo(pkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) { false }
}
